<?php if(isset($username)){echo '<h2>hello '.$username.'</h2>';} ?>
