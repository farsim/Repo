<?php if(isset($username)){echo '<h2>hello '.$username.'</h2>';} ?>
<p><?php if(isset($unionname)){echo $unionname.' Union';} ?></p>

