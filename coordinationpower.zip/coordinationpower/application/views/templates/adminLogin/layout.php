<!DOCTYPE html>
<html>
    <head>
        <title>Coordinator Power::Admin</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url().'public/admin/css/style.css'?>" />
        <script type="text/javascript" charset="utf-8" src="<?php echo base_url().'public/script/jquery-1.6.min.js'?>"></script>
    </head>
    <body>
        <div id="header">
            <h1>Co-ordination Power App</h1>
        </div>
        <div id="content"><?php echo $content; ?></div>
        <div id="footer"></div>
    </body>
</html>
